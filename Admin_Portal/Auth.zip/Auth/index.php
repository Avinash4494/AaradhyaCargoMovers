<?php
	include 'indexRedirect.php';
?>
 
<!DOCTYPE html>
<html lang="en">
	<title>Admin - Login</title>
	    <link rel="icon" href="../../image/logo_A.png">
	<body>
		<?php include_once '../../Header_Links/noAnim_links.php' ?>
		<div class="wrapperComponentLogin">
			<div class="container-fluid">
				<div class="row">
				<div class="col-lg-6">
						<div class="WrapperLogoReg hidden-xs">
							<a href="../../index.php" data-toggle="tooltip" title="Back to Home!" data-placement="bottom">
								<div class="row">
									<div class="col-lg-4">
										<img src="../image/mainlogo.png" class="img-responsive" alt="">
									</div>
									<div class="col-lg-8"></div>
								</div>
								<div class="row">
									<div class="col-lg-12">
										<h3>Welcome to</h3>
										<h1>Aaradhya Cargo Movers</h1>
									</div>
								</div>
							</a>
						</div>
					</div>
					<div class="col-lg-2"></div>
					<div class="col-lg-4">
						<div class="loginPannel">
							<div class="well">
								<div class="tab-content">
									
									<div id="adminLogin" class="tab-pane fade in active">
										<div class="sectionHead">
											<div class="row">
												<div class="col-lg-4 col-xs-3"></div>
												<div class="col-lg-4 col-xs-6">
													<img src="../image/admin.png" alt="" class="img-responsive">
												</div>
												<div class="col-lg-4 col-xs-3"></div>
											</div>
											<h2>Admin Log In</h2>
										</div>
										<div class="formSectionLogin">
											<p id="AllFields" ></p>
											<form  action="loginProcess.php" name ="register" method="POST" onsubmit="return myvalidate();">
												<input type="text" class="log_activity_id" name="log_activity_id" hidden="">
												<input type="date" class="log_time" name="log_time" hidden="">
												<input type="date" class="log_out_time" name="log_out_time" hidden="" value="0">
												 
												<input type="text" class="log_ip_address" name="log_ip_address" hidden="" value="0">
												 
												<input type="text" class="log_user_location" name="log_user_location" hidden="" value="0">
												<div class="form-group">
													<div class="row">
														<div class="col-lg-6">
															<label for="">Username <span>*</span></label>
														</div>
														<div class="col-lg-6">
															<h6>Need an account? <a href="Register.php">Sign Up</a></h6>
														</div>
													</div>
													<input type="text" onkeyup="usernameValidate()"  class="form-control" id="username" placeholder="Username" name="admin_id">
													<span id='usernameError'></span>
												</div>
												<div class="form-group">
													<label for="">Password <span>*</span></label>
													<input type="password" onkeyup="passwordValidate()" id="pass" class="form-control" placeholder="******" name="password">
													<span id='passwordError'></span>
												</div>
												<button type="submit" class="actionButtonIcons-login">Log In</button>
												<!-- <p id="OkFields"></p> -->
											</form>
										</div>
										<div class="row">
											<div class="col-lg-12">
												
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
<script>
	function myvalidate()
{
var username=document.getElementById("username").value;
var password=document.getElementById("pass").value;
if(username.length==0||password.length==0)
{
document.getElementById("AllFields").innerHTML="* All Fields are required";
return false;
}
else
{
document.getElementById("OkFields").innerHTML="Valid name";
return true;
}
}
	
	function usernameValidate()
{
var username = document.forms["register"]["username"];
if (username.value == "")
{
document.getElementById("usernameError").innerHTML="* Please enter valid Username";
username.focus();
return false;
}
else
{
document.getElementById("usernameError").innerHTML="";
}
}
function passwordValidate()
{
var password = document.forms["register"]["pass"];
if (password.value == "")
{
document.getElementById("passwordError").innerHTML="* Please enter valid Password";
password.focus();
return false;
}
else
{
document.getElementById("passwordError").innerHTML="";
}
}
</script>