<?php
include_once '../db.php';
if(isset($_POST['submit']))
{

$Name = $_POST['Fullname'];
$admin_id = $_POST['admin_id'];
$admin_id_gen = 'ACM'.'-'.rand(100000,999999);
$mobile = $_POST['mobile'];
$password = $_POST['PASSWORD'];
$repassword = $_POST['repassword'];
$Email = $_POST['Email'];
$Question = $_POST['Question'];
$Answer = $_POST['Answer'];
$random_id = $_POST['random_user_id'];

$dob = $_POST['dob'];
$gender = $_POST['gender'];
$alternate_phone = $_POST['alternate_phone'];
$present_address = $_POST['present_address'];
$present_state = $_POST['present_state'];
$present_pincode = $_POST['present_pincode'];
$permanent_address = $_POST['permanent_address'];
$permanent_state = $_POST['permanent_state'];
$permanent_pincode = $_POST['permanent_pincode'];
$pan_num = $_POST['pan_num'];
$aadhar_num = $_POST['aadhar_num'];
$aadhar_name = $_POST['aadhar_name'];
$aadhar_dob = $_POST['aadhar_dob'];
$country_birth = $_POST['country_birth'];
$blood_grp = $_POST['blood_grp'];
$birth_place = $_POST['birth_place'];
$martial_status = $_POST['martial_status'];
$father_name = $_POST['father_name'];
$father_dob = $_POST['father_dob'];
$nationality = $_POST['nationality'];

$record_name = $_POST['record_name'];
$bank_account_num = $_POST['bank_account_num'];
$bank_name = $_POST['bank_name'];
$bank_code = $_POST['bank_code'];
$bank_city = $_POST['bank_city'];
$bank_country = $_POST['bank_country'];
$bank_ifsc_code = $_POST['bank_ifsc_code'];
$bank_type = $_POST['bank_type'];
$bank_confirm = $_POST['bank_confirm'];
$bank_joint_confirm = $_POST['bank_joint_confirm'];

$address_upDate = $_POST['address_upDate'];
$profile_upDate = $_POST['profile_upDate'];
$pic_upDate = $_POST['pic_upDate'];

$auth_status = $_POST['auth_status'];

$profile_image = $_POST['profile_image'];
$check = mysqli_query($connect,"SELECT * FROM admin_login WHERE admin_id='".$admin_id."'") or die("Check Query");
if(mysqli_num_rows($check) == 0)
{
if($repassword == $password)
{
if($query = mysqli_query($connect,"INSERT INTO admin_login(Fullname,admin_id,mobile,PASSWORD,Email,Question,Answer,random_user_id,dob,gender,alternate_phone,present_address,present_state,present_pincode,permanent_address,permanent_state,permanent_pincode,pan_num,aadhar_num,aadhar_name,aadhar_dob,country_birth,blood_grp,birth_place,martial_status,father_name,father_dob,nationality,record_name,bank_account_num,bank_name,bank_code,bank_city,bank_country,bank_ifsc_code,bank_confirm,bank_joint_confirm,address_upDate,profile_upDate,pic_upDate,auth_status,profile_image) 

	VALUES ('$Name', '$admin_id_gen','$mobile', '$password','$Email','$Question','$Answer','$random_id','$dob','$gender','$alternate_phone','$present_address','$present_state','$present_pincode','$permanent_address','$permanent_state','$permanent_pincode',
'$pan_num','$aadhar_num','$aadhar_name','$aadhar_dob','$country_birth','$blood_grp','$birth_place','$martial_status','$father_name','$father_dob','$nationality','$record_name','$bank_account_num','$bank_name','$bank_code','$bank_city','$bank_country','$bank_ifsc_code','$bank_confirm','$bank_joint_confirm','$address_upDate','$profile_upDate','$pic_upDate','$auth_status','$profile_image')"))
{
echo '<script>
setTimeout(function(){ window.location.href="addedSuccessReg.php"; }, 1000);
</script>';
}
}
else
{
echo '<script>
setTimeout(function(){ window.location.href="passError.php"; }, 500);
</script>';
}
}
else
{
echo '<script>

setTimeout(function(){ window.location.href="name_error.php"; }, 500);
</script>';
}
}
?>